<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version details
 *
 * @package    block_openai_questions
 * @copyright  2022 Bryce Yoder (me@bryceyoder.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2026111400;        // Maintenance release: 14 November 2026.
$plugin->requires  = 2024100700;        // Moodle 4.5.0 or later is required.
$plugin->supported = [405, 405];       // This maintenance branch targets Moodle 4.5.
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.2.1-hkobayashi.1';
$plugin->component = 'block_openai_questions'; // Full name of the plugin (used for diagnostics)
